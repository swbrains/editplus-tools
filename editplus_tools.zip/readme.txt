ColorPicker.exe:
This application runs as a stay on top window that displays a grid of 
named HTML colors. Selecting a cell displays its HTML name as well as 
its hex color code.  Double-clicking a cell or the name field puts the
name on the clipboard, pastes it into the currently open EditPlus window
and closes the application.  Double-clicking the hex code field puts
the hex code on the clipboard, pastes it into the currently open EditPlus
window and closes the application. 

Optional command-line parameters:
stayopen : causes the application to stay open after pasting the selected color.
returnhex: causes the application to return the hex color code by default. 	

HTMLEntities.exe:
This application runs as a stay on top window that displays a grid of 
special characters and their HTML entity names. Selecting a cell displays 
its entity name as well as its HTML hex code.  Double-clicking a cell or 
the name field puts the entity name on the clipboard, pastes it into the 
currently open EditPlus window and closes the application.  Double-clicking 
the hex code field puts the HTML hex code on the clipboard, pastes it into 
the currently open EditPlus window and closes the application. 

Optional command-line parameters:
stayopen : causes the application to stay open after pasting the selected color.
returnhex: causes the application to return the hex color code by default.

The applications can run without EditPlus editor, however they will only 
copy the selected item to the clipboard.  It will not be pasted into any
other application.
